import React, { useEffect, useState } from 'react'

function Card({ name, gender, setIndex, frendsLength, index, category }) {
  const [menu, setMenu] = useState(true)
  const [answer, setAnswer] = useState(false)
  const [text, setText] = useState("")

  useEffect(() => {
    setMenu(true)
    setAnswer(false)
    setText("")
  }, [index]);

  useEffect(() => {
    if (!answer) return
    API.get("random-exercise", { gender, category, answer: answer == "pflicht" }).then(setText)
  }, [answer])

  useEffect(() => log(text), [text])

  return (
    <div className="card mt-5" style={{ width: "18rem" }}>
      <div className="card-body">
        <h5 className="card-title">{name}</h5>
        {menu ?
          <div onClick={e => setMenu(false)}>
            <button
              onClick={e => setAnswer("warheit")}
              className='btn btn-warning mb-2'>
              Warheit
            </button>
            <span>
              {" oder "}
            </span>
            <button
              onClick={e => setAnswer("pflicht")}
              className='btn btn-danger mb-2'>
              Pflicht
            </button>
          </div>
          :
          <p className="card-text">{text}</p>
        }
        <button onClick={e => {
          setIndex(old => {
            if (old - 1 < 0) {
              return frendsLength - 1
            }
            else return old - 1
          })
        }} className="card-link btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M220-240v-480h80v480h-80Zm520 0L380-480l360-240v480Zm-80-240Zm0 90v-180l-136 90 136 90Z" /></svg>
        </button>
        <button onClick={e => {
          setIndex(old => {
            if (old + 1 > frendsLength - 1) {
              return 0
            }
            else return old + 1
          })
        }} className="card-link btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M660-240v-480h80v480h-80Zm-440 0v-480l360 240-360 240Zm80-240Zm0 90 136-90-136-90v180Z" /></svg>
        </button>
      </div>
    </div>
  )
}

export default Card