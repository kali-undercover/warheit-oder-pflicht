import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import Card from '../comp/card'

function Game({ frends }) {
    const { category } = useParams()
    const [index, setIndex] = useState(0)

    useEffect(() => {

    }, [index])

    return (
        <div className='container'>
            <Card category={category} gender={frends?.[index]?.men} name={frends?.[index]?.name} index={index} setIndex={setIndex} frendsLength={frends.length} />
        </div>
    )
}

export default Game