import React, { useState } from 'react'

function Create({ categorys }) {
    const [category, setCategory] = useState(categorys[0])
    const [gender, setGender] = useState(true)
    const [answer, setAnswer] = useState(true)
    const [exercise, setExercise] = useState("")

    return (
        <div className='container'>
            <select className='form-control mt-2' onChange={e => setCategory(e.target.value)}>
                {categorys.map(c => <option value={c} key={c}>{c}</option>)}
            </select>
            <button onClick={e => {
                e.preventDefault()
                setGender(o => !o)
            }} role='button' className='btn btn-primary mt-2' style={{ backgroundColor: gender ? "" : "#FF00B8", transition: "all 0.3s ease-in-out" }}>
                {gender ?
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M800-800v240h-80v-103L561-505q19 28 29 59.5t10 65.5q0 92-64 156t-156 64q-92 0-156-64t-64-156q0-92 64-156t156-64q33 0 65 9.5t59 29.5l159-159H560v-80h240ZM380-520q-58 0-99 41t-41 99q0 58 41 99t99 41q58 0 99-41t41-99q0-58-41-99t-99-41Z" /></svg> :
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M440-120v-80h-80v-80h80v-84q-79-14-129.5-75.5T260-582q0-91 64.5-154.5T480-800q91 0 155.5 63.5T700-582q0 81-50.5 142.5T520-364v84h80v80h-80v80h-80Zm40-320q58 0 99-41t41-99q0-58-41-99t-99-41q-58 0-99 41t-41 99q0 58 41 99t99 41Z" /></svg>
                }
            </button>
            <br />
            <button onClick={e => {
                setAnswer(old => !old)
            }} role='button' className={`btn ${answer ? "btn-danger" : "btn-warning"} mt-2`}>
                {answer ? "pflicht" : "warheit"}
            </button>
            <br />
            <input type="text" className='form-control mt-2' placeholder={answer ? "Pflicht..." : "Warheit..."} value={exercise} onChange={e => setExercise(e.target.value)} />
            <button className='btn btn-primary mt-2' onClick={async e => {
                const data = await API.get("create-exercise", {
                    gender, category, answer, exercise
                })
                if (data)
                    setExercise("Uploaded👍")
            }}>Upload</button>
        </div>
    )
}

export default Create