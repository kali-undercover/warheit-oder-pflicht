import React, { useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'

function Play({ frends, setFrends }) {
    const { category } = useParams()
    const name = useRef()
    const [isMen, setIsMen] = useState(true)

    return (
        <div className='container'>
            <h1>{category}</h1>
            <ul className="list-group list-group-flush">
                {frends.map(({ name, men, id }, i) =>
                    <li key={id} className="list-group-item">
                        <button onClick={e => {
                            setFrends([...frends.filter((elem, index) => {
                                return i != index
                            })])
                        }} role='button' className='btn btn-danger' style={{ marginRight: "5px" }}>
                            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" /></svg>
                        </button>
                        <button onClick={e => {
                            setFrends([...frends.map((elem, index) => {
                                if (i != index) return elem
                                return { ...elem, men: !elem.men }
                            })])
                        }} role='button' className='btn btn-primary' style={{ marginRight: "5px", backgroundColor: men ? "" : "#FF00B8", transition: "all 0.3s ease-in-out" }}>
                            {men ?
                                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M800-800v240h-80v-103L561-505q19 28 29 59.5t10 65.5q0 92-64 156t-156 64q-92 0-156-64t-64-156q0-92 64-156t156-64q33 0 65 9.5t59 29.5l159-159H560v-80h240ZM380-520q-58 0-99 41t-41 99q0 58 41 99t99 41q58 0 99-41t41-99q0-58-41-99t-99-41Z" /></svg> :
                                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M440-120v-80h-80v-80h80v-84q-79-14-129.5-75.5T260-582q0-91 64.5-154.5T480-800q91 0 155.5 63.5T700-582q0 81-50.5 142.5T520-364v84h80v80h-80v80h-80Zm40-320q58 0 99-41t41-99q0-58-41-99t-99-41q-58 0-99 41t-41 99q0 58 41 99t99 41Z" /></svg>
                            }
                        </button>
                        <span>
                            {name}
                        </span>
                    </li>
                )}
            </ul>
            <form onSubmit={e => {
                e.preventDefault()
                setFrends([...frends, { name: name.current?.value, men: isMen, id: Math.random() }])
                name.current.value = ""
            }}>
                <div className="form-group">
                    <label htmlFor="nameInput">Name</label>
                    <input ref={name} type="text" className="form-control mb-2" id="nameInput" aria-describedby="name" placeholder="New Name..." />
                </div>
                <button onClick={e => {
                    e.preventDefault()
                    setIsMen(o => !o)
                }} role='button' className='btn btn-primary' style={{ marginRight: "5px", backgroundColor: isMen ? "" : "#FF00B8", transition: "all 0.3s ease-in-out" }}>
                    {isMen ?
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M800-800v240h-80v-103L561-505q19 28 29 59.5t10 65.5q0 92-64 156t-156 64q-92 0-156-64t-64-156q0-92 64-156t156-64q33 0 65 9.5t59 29.5l159-159H560v-80h240ZM380-520q-58 0-99 41t-41 99q0 58 41 99t99 41q58 0 99-41t41-99q0-58-41-99t-99-41Z" /></svg> :
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M440-120v-80h-80v-80h80v-84q-79-14-129.5-75.5T260-582q0-91 64.5-154.5T480-800q91 0 155.5 63.5T700-582q0 81-50.5 142.5T520-364v84h80v80h-80v80h-80Zm40-320q58 0 99-41t41-99q0-58-41-99t-99-41q-58 0-99 41t-41 99q0 58 41 99t99 41Z" /></svg>
                    }
                </button>
                <button type="submit" className="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" /></svg>
                </button>
            </form>
            <Link to={`/game/${category}`} className='btn btn-primary mt-2'>
                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M320-200v-560l440 280-440 280Zm80-280Zm0 134 210-134-210-134v268Z" /></svg>
            </Link>
        </div>
    )
}

export default Play