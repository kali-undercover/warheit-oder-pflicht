import { Link } from "react-router-dom";

function Home({ categorys }) {
  return (
    <div className="container">
      <h1 className="mt-2">
        Warheit oder Pflicht
      </h1>
      <ul className="list-group list-group-flush">
        {categorys.map(name =>
          <Link key={name} to={`play/${name}`} className="list-group-item">
            <li>{name}</li>
          </Link>
        )}
      </ul>
      <Link to={"create"} className="btn btn-primary">Erstellen</Link>
    </div>
  );
}

export default Home;