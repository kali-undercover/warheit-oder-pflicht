import { Routes, Route } from "react-router-dom";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import Play from "./pages/play";
import useLocalStorage from "use-local-storage"
import Game from "./pages/game";
import Create from "./pages/create";

function App() {
  const categorys = ["normal", "sexy", "hot", "extreme"]
  const [frends, setFrends] = useLocalStorage(projectID + "frends", [])

  return (
    <Routes>
      <Route path="/" element={<Home categorys={categorys} />} />
      <Route path="/play/:category" element={<Play frends={frends} setFrends={setFrends} />} />
      <Route path="/game/:category" element={<Game frends={frends} />} />
      <Route path="/create" element={<Create categorys={categorys} />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
