import Client from "../../WSNET_Framework/_client/index.js";
import LoadingPage from "./pages/loading-page.jsx";
import { HashRouter } from "react-router-dom";
import ReactDOM from "react-dom/client";
import React, { useState } from "react";
import NavBar from "./comp/nav-bar";
import App from "./App.jsx";
import "./index.css";
//create the api conection
window.API = new Client(apiurl);
API.onclose = () => window.location.reload();
API.onerror = () => window.location.reload();

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <HashRouter>
      <NavBar />
      <Main />
    </HashRouter>
  </React.StrictMode>
);

var isOpen = false,
  setIsOpen = () => false;

//auth
API.onopen = async () => {
  isOpen = true
  setIsOpen(true)
};

//render the app or the loading
function Main() {
  [isOpen, setIsOpen] = useState(isOpen);
  return isOpen ? <App /> : <LoadingPage />;
}
