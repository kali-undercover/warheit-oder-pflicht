const { createServer } = require("./WSNET_Framework/_server/index.js");
const { log } = require("console");
const fs = require("fs");
const port = 8080;

const categorys = ["normal", "sexy", "hot", "extreme"]

const data = JSON.parse(fs.readFileSync("data.txt", "utf-8")) || {
    fe: {
        pflicht: {
            normal: {},
            sexy: {},
            hot: {},
            extreme: {}
        },
        warheit: {
            normal: {},
            sexy: {},
            hot: {},
            extreme: {}
        }
    },
    ma: {
        pflicht: {
            normal: {},
            sexy: {},
            hot: {},
            extreme: {}
        },
        warheit: {
            normal: {},
            sexy: {},
            hot: {},
            extreme: {}
        }
    },
}

createServer({ port }, async client => {

    client.onGet("create-exercise", req => {
        const gender = req?.gender ? "ma" : "fe",
            category = req?.category + "",
            answer = req?.answer ? "pflicht" : "warheit",
            exercise = req?.exercise + "";
        if (!categorys.includes(category)) return false
        data[gender][answer][category][exercise] = true
        return true
    })

    client.onGet("random-exercise", req => {
        const gender = req?.gender ? "ma" : "fe",
            category = req?.category + "",
            answer = req?.answer ? "pflicht" : "warheit";
        if (!categorys.includes(category)) return false
        const keys = Object.keys(data[gender][answer][category]) || []
        return keys[Math.floor(Math.random() * keys.length)] || "no data"
    })

})

setInterval(() => fs.writeFileSync("data.txt", JSON.stringify(data, false, 4), "utf-8"), 10000)

process.on("uncaughtException", err => log(err))